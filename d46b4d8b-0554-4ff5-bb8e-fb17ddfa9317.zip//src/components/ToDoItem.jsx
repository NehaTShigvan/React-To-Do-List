import React, { useState } from "react";

function ToDoItem(props) {
  return (
    <div
      onClick={() => {
        props.onChecked(props.id);
      }}
    >
      {" "}
      <li>{props.item}</li>
    </div>
  );
}

export default ToDoItem;

// function ToDoItem(props) {
//     const [isLined, setLined] = useState(false);

//     function handleClick() {
//       setLined((prevValue) => !prevValue);
//     }

//     return (
//       <ul>
//         {props.list.map((todoItem) => (
//           <li
//             onClick={handleClick}
//             style={{ textDecoration: isLined ? "line-through" : "none" }}
//           >
//             {todoItem}
//           </li>
//         ))}
//       </ul>
//     );
//   }
